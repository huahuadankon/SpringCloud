package com.alibaba.csp.sentinel.adapter.spring.webmvc.exception;

/**
 * @author lemonj
 */
public class BizException extends RuntimeException{
}
