# Security Policy

## Reporting a security issue

If you think the bug you found is likely to make Sentinel-based applications vulnerable to an attack, please do not use
our public issue tracker but report it to [ASRC(Alibaba Security Response Center)](https://security.alibaba.com/).
